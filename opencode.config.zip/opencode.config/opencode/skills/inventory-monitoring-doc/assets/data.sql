-- ============================================================
-- 種子資料 - products 表（20 筆代表性資料）
-- 用於快速驗證庫存監控功能
-- ============================================================

INSERT INTO products (productCode, productName, productLine, productScale, productVendor, productDescription, quantityInStock, buyPrice, MSRP) VALUES
-- Classic Cars (高庫存)
('S10_1678', '1969 Harley Davidson Ultimate Chopper', 'Classic Cars', '1:10', 'Min Lin Diecast', 'This replica features working kick-start, pedal and hand chain detailing features actual cherry-red paint job. Scale 1:10.', 7933, 48.81, 95.70),
('S10_1949', '1952 Alpine Renault 1300', 'Classic Cars', '1:10', 'Classic Metal Creations', 'Turnable front wheels; steering function; detailed interior; detailed engine; opening hood.', 7305, 98.58, 214.30),
('S10_2016', '1968 Mini Special', 'Classic Cars', '1:10', 'Mini Classics', 'Open doors, small interior, working steering wheel with turning front wheels, detailed interior and engine.', 6791, 53.91, 119.80),
('S10_4698', '2003 Harley-Davidson Eagle Drag Bike', 'Classic Cars', '1:10', 'Red Start Diecast', 'Highly detailed 1:10 scale die-cast model of the 2003 Harley-Davidson Drag Bike.', 5582, 91.02, 193.66),
('S10_4962', '1962 LanciaA Delta 16V', 'Classic Cars', '1:10', 'Second Gear Diecast', 'Features include: opening hood, opening doors, detailed interior, opening trunk, working steering wheel.', 14, 103.42, 147.74),

-- Motorcycles (中低庫存)
('S18_1749', '1929 British Racing Green Silverstone', 'Motorcycles', '1:18', 'Studio M Art Models', 'The 1929 British Racing Green car has many fine details including chrome hubcaps, rear-mounted spare tire, working steering wheel.', 95, 60.86, 96.77),
('S18_2248', '1958 Chevy Pastel Blue', 'Motorcycles', '1:18', 'Red Start Diecast', 'This 1:18 scale die-cast model features working doors, hood, trunk, detailed interior and trunk.', 230, 55.70, 118.50),
('S18_2625', '1956 Pink Porsche 356A Roadster', 'Motorcycles', '1:18', 'Gearbox Collectibles', 'This 1:18 scale die-cast replica features hand-assembled engine, detailed interior, and working suspension.', 66, 53.91, 101.51),

-- Planes (高庫存)
('S12_1099', '1968 Ford Mustang', 'Planes', '1:12', 'Autoart Studio Design', 'Under hood of this model you will find accurate representation of the V-8 engine with air cleaner, battery, radiator fan, and much more.', 68, 95.70, 194.97),
('S12_3891', '1969 Ford Falcon', 'Planes', '1:12', 'Second Gear Diecast', 'Turnable front wheels; steering function; detailed interior; detailed engine; opening hood.', 1049, 73.49, 173.02),
('S18_4409', '1932 Alfa Romeo 8C23000 Spider Sport', 'Planes', '1:18', 'Exoto Designs', 'This 1:18 scale die-cast model features accurate exterior and interior detail. Under the hood you will find a detailed V-12 engine.', 86, 43.26, 65.75),

-- Trucks and Buses (低庫存)
('S18_1129', '1993 Mazda RX-7', 'Trucks and Buses', '1:18', 'Highway 66 Mini Classics', 'This model features rubber tires, steerable front wheels, detailed engine, opening hood and doors.', 184, 53.91, 141.54),
('S18_1589', '1965 Aston Martin DB5', 'Trucks and Buses', '1:18', 'Classic Metal Creations', 'This 1:18 scale die-cast replica features working doors, hood, trunk, detailed interior and trunk.', 9047, 65.96, 93.81),
('S18_3685', '1948 Porsche 356-A Roadster', 'Trucks and Buses', '1:18', 'Gearbox Collectibles', 'This model features rubber tires, steerable front wheels, detailed engine, opening hood and doors.', 8826, 53.90, 98.30),

-- Ships (極低庫存)
('S18_3856', '1995 Honda Civic', 'Ships', '1:18', 'Min Lin Diecast', 'This model features rubber tires, steerable front wheels, detailed engine, opening hood and doors.', 97, 93.53, 142.25),
('S24_2000', '1960 BSA Gold Star DBD34', 'Ships', '1:24', 'Classic Metal Creations', 'Highly detailed 1:24 scale die-cast model of the 1960 BSA Gold Star DBD34 motorcycle.', 15, 37.32, 76.56),

-- Vintage Cars (中等庫存)
('S18_1984', '1995 Alpine Sprint Coupe', 'Vintage Cars', '1:18', 'Motor City Art Classics', 'Features include: opening hood, opening doors, detailed interior, opening trunk, working steering wheel.', 332, 56.76, 107.00),
('S18_2795', '1999 Yamaha Speed Boat', 'Vintage Cars', '1:18', 'United Models', '1:18 scale die-cast model of the 1999 Yamaha Speed Boat. Features accurate exterior and interior detail.', 4259, 51.61, 86.02),
('S24_1628', '1966 Shelby Cobra 427 S/C', 'Vintage Cars', '1:24', 'Classic Metal Creations', 'This 1:24 scale die-cast replica features hand-assembled engine, detailed interior, and working suspension.', 8197, 81.03, 124.81);
