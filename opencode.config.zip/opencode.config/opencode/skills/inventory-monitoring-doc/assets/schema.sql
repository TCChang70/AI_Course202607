-- ============================================================
-- 庫存監控模組 - 資料庫初始化腳本
-- 使用前請先建立資料庫：CREATE DATABASE classicmodels CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- ============================================================

-- -----------------------------------------------------------
-- 1. 既有 products 表（沿用 classicmodels 範例資料庫）
-- -----------------------------------------------------------
-- 如果 products 表已存在，可跳過此區塊
CREATE TABLE IF NOT EXISTS products (
    productCode VARCHAR(15) NOT NULL,
    productName VARCHAR(70) NOT NULL,
    productLine VARCHAR(50) NOT NULL,
    productScale VARCHAR(10) NOT NULL,
    productVendor VARCHAR(50) NOT NULL,
    productDescription TEXT,
    quantityInStock SMALLINT NOT NULL,
    buyPrice DECIMAL(10,2) NOT NULL,
    MSRP DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (productCode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------
-- 2. 新增 stock_thresholds 安全水位表
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS stock_thresholds (
    id BIGINT NOT NULL AUTO_INCREMENT,
    product_code VARCHAR(15) NOT NULL,
    min_quantity INT NOT NULL DEFAULT 200,
    reorder_quantity INT NOT NULL DEFAULT 500,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_stock_thresholds_product_code (product_code),
    CONSTRAINT fk_stock_thresholds_products
        FOREIGN KEY (product_code) REFERENCES products (productCode)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------
-- 3. 種子資料：seed_thresholds.sql
-- 預設水位設定（5 筆低庫存產品）
-- -----------------------------------------------------------
INSERT INTO stock_thresholds (product_code, min_quantity, reorder_quantity) VALUES
('S18_1749', 150, 300),   -- 低庫存示範 1
('S18_2248', 100, 250),   -- 低庫存示範 2
('S18_2625', 120, 280),   -- 低庫存示範 3
('S24_2000', 180, 350),   -- 中等庫存示範
('S24_3856', 90, 200);    -- 極低庫存示範

-- -----------------------------------------------------------
-- 4. 常用查詢（驗證用）
-- -----------------------------------------------------------
-- 查詢所有低庫存產品（庫存 < 安全水位）
-- SELECT p.productCode, p.productName, p.quantityInStock, st.min_quantity, st.reorder_quantity
-- FROM products p
-- JOIN stock_thresholds st ON p.productCode = st.product_code
-- WHERE p.quantityInStock < st.min_quantity
-- ORDER BY p.quantityInStock ASC;

-- 查詢各產品線庫存統計
-- SELECT productLine,
--        SUM(quantityInStock) AS totalStock,
--        COUNT(*) AS productCount,
--        MIN(quantityInStock) AS minStock
-- FROM products
-- GROUP BY productLine
-- ORDER BY totalStock DESC;

-- 查詢緊急補貨清單（庫存 < 安全水位的 50%）
-- SELECT p.productCode, p.productName, p.quantityInStock, st.min_quantity,
--        ROUND(p.quantityInStock / st.min_quantity * 100, 1) AS stockRatio
-- FROM products p
-- JOIN stock_thresholds st ON p.productCode = st.product_code
-- WHERE p.quantityInStock < (st.min_quantity * 0.5)
-- ORDER BY stockRatio ASC;
