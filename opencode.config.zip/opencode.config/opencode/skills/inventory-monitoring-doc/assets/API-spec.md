# 庫存監控模組 - API 規格

## 統一回傳格式

**成功**
```json
{ "success": true, "message": "...", "data": { ... } }
```

**失敗**
```json
{ "success": false, "errorCode": "NOT_FOUND", "message": "Product not found: S99_9999" }
```

## 端點總表

### 1. 產品管理 (FR-01)

| 方法 | 路徑 | 功能 | 狀態碼 |
|------|------|------|--------|
| GET | /api/products | 產品列表（可搜尋/篩選） | 200 |
| GET | /api/products/{productCode} | 單一產品詳細 | 200 / 404 |
| POST | /api/products | 新增產品 | 201 / 400 |
| PUT | /api/products/{productCode} | 更新產品 | 200 / 400 / 404 |
| DELETE | /api/products/{productCode} | 刪除產品 | 200 / 404 |
| GET | /api/products/product-lines | 產品線清單（下拉選單用） | 200 |
| GET | /api/products/vendors | 供應商清單（下拉選單用） | 200 |

### 2. 庫存監控 (FR-02)

| 方法 | 路徑 | 功能 | 狀態碼 |
|------|------|------|--------|
| GET | /api/low-stock | 低庫存警示清單 | 200 |
| GET | /api/thresholds | 所有安全水位設定 | 200 |
| PUT | /api/thresholds/{productCode} | 新增/更新安全水位（upsert） | 200 / 400 / 404 |
| GET | /api/dashboard/summary | Dashboard 統計（卡片 + 產品線明細） | 200 |

## 查詢參數

### GET /api/products
| 參數 | 型別 | 必填 | 說明 |
|------|------|------|------|
| keyword | String | 否 | 關鍵字搜尋（名稱、產品線、供應商） |
| productLine | String | 否 | 產品線篩選 |
| vendor | String | 否 | 供應商篩選 |
| lowStockOnly | boolean | 否 | 只回傳低庫存產品 |

## Dashboard 回應結構
```json
{
  "success": true,
  "data": {
    "totalProducts": 110,
    "lowStockCount": 3,
    "totalInventoryValue": 2055180.65,
    "totalStockUnits": 311558,
    "productLineSummary": [
      { "productLine": "Classic Cars", "productCount": 38, "totalStock": 1924933, "avgStock": 50656.13 },
      { "productLine": "Motorcycles", "productCount": 13, "totalStock": 569780, "avgStock": 43829.23 }
    ]
  }
}
```
