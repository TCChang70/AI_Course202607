# 庫存監控模組

基於 Spring Boot + 多前端（Angular / React / Vite React）的庫存監控系統範例。

## 技術棧

| 分類 | 技術 |
|------|------|
| 後端 | Spring Boot 3.2 / Java 17 / Maven / Spring Data JPA / MySQL |
| 前端 Angular | Angular 17 Standalone + HttpClient + RxJS |
| 前端 React | React 18 + React Router v6 + Axios + Bootstrap 5 + TypeScript |
| 前端 Vite React | React 18 + Vite + React Router v6 + JavaScript |

## 需求功能

- **FR-01 產品管理**：CRUD、關鍵字搜尋、產品線/供應商篩選
- **FR-02 庫存監控**：安全水位設定、低庫存警示、補貨清理單、Dashboard 統計

## 專案結構

```
inventory-monitor/
├── backend/                 # Spring Boot 後端
│   ├── src/main/java/com/classicmodels/inventory/
│   │   ├── controller/      # ProductController / ThresholdController / DashboardController
│   │   ├── service/         # ProductService / StockThresholdService
│   │   ├── repository/      # ProductRepository / StockThresholdRepository
│   │   ├── model/           # Product / StockThreshold (Entity)
│   │   ├── dto/             # ProductDTO / StockThresholdDTO / StockSummary / LowStockItem
│   │   ├── config/          # CorsConfig / DataInitializer
│   │   ├── exception/       # GlobalExceptionHandler / ResourceNotFoundException
│   │   └── InventoryApplication.java
│   └── src/main/resources/application.properties
├── frontend-angular/        # Angular 17 + TypeScript
├── frontend-react/          # CRA + React 18 + TypeScript
├── frontend-vite-react/     # Vite + React 18 + JavaScript
└── sql/                     # schema.sql / data.sql / seed_thresholds.sql
```

## 快速開始

### 1. 建立資料庫
```bash
mysql -u root -p < sql/schema.sql
mysql -u root -p classicmodels < sql/data.sql
mysql -u root -p classicmodels < sql/seed_thresholds.sql
```

### 2. 啟動後端
```bash
cd backend
mvn spring-boot:run
# 需要先在 application.properties 設定 MySQL 帳密
```

### 3. 啟動前端（擇一）
```bash
# Angular (port 4200)
cd frontend-angular && npm install && ng serve

# React (port 3000)
cd frontend-react && npm install && npm start

# Vite React (port 5173)
cd frontend-vite-react && npm install && npm run dev
```

## API 端點

| 方法 | 路徑 | 說明 |
|------|------|------|
| GET | /api/products | 產品列表（可帶 keyword/productLine/vendor 參數） |
| GET | /api/products/{code} | 產品詳細 |
| POST | /api/products | 新增產品 |
| PUT | /api/products/{code} | 更新產品 |
| DELETE | /api/products/{code} | 刪除產品 |
| GET | /api/thresholds | 安全水位列表 |
| PUT | /api/thresholds/{code} | 更新安全水位（upsert） |
| GET | /api/low-stock | 低庫存警示清單 |
| GET | /api/dashboard/summary | Dashboard 統計（含產品線明細） |

## 驗證工具

- Swagger UI: http://localhost:8080/swagger-ui.html
- Postman Collection: `postman/庫存監控模組.postman_collection.json`
