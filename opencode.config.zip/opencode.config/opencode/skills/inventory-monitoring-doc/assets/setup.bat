@echo off
REM ============================================================
REM 庫存監控模組 - Windows 安裝腳本
REM ============================================================

echo ==========================================
echo  庫存監控模組 - 環境安裝
echo ==========================================

REM --- 1. 檢查 Java ---
echo.
echo [1/5] 檢查 Java 版本...
java -version 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 找不到 Java，請先安裝 JDK 17
    echo    下載: https://adoptium.net/
    exit /b 1
)
echo ✅ Java 已安裝

REM --- 2. 檢查 Maven ---
echo.
echo [2/5] 檢查 Maven 版本...
mvn -version 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 找不到 Maven，請先安裝 Apache Maven
    echo    下載: https://maven.apache.org/download.cgi
    exit /b 1
)
echo ✅ Maven 已安裝

REM --- 3. 檢查 Node.js ---
echo.
echo [3/5] 檢查 Node.js 版本...
node -v 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 找不到 Node.js，請先安裝 Node.js 18+
    echo    下載: https://nodejs.org/
    exit /b 1
)
echo ✅ Node.js 已安裝

REM --- 4. 初始化資料庫 ---
echo.
echo [4/5] 初始化 MySQL 資料庫...
echo 請手動執行以下 SQL 腳本：
echo    1. mysql -u root -p ^< assets/schema.sql
echo    2. mysql -u root -p classicmodels ^< assets/data.sql
echo    3. mysql -u root -p classicmodels ^< assets/seed_thresholds.sql
echo.

REM --- 5. 啟動後端 ---
echo.
echo [5/5] 啟動 Spring Boot 後端...
echo.
cd backend
echo 執行: mvn spring-boot:run
echo （或在 IDE 中執行 InventoryApplication.java）
echo.
cd ..

REM --- 6. 啟動前端（擇一）---
echo ==========================================
echo  前端啟動方式（擇一）：
echo ==========================================
echo.
echo  Angular:    cd frontend-angular ^&^& npm install ^&^& ng serve
echo  React:      cd frontend-react ^&^& npm install ^&^& npm start
echo  Vite React: cd frontend-vite-react ^&^& npm install ^&^& npm run dev
echo.

echo ==========================================
echo  安裝完成！
echo  後端: http://localhost:8080
echo  Angular: http://localhost:4200
echo  React: http://localhost:3000
echo  Vite: http://localhost:5173
echo ==========================================
pause
