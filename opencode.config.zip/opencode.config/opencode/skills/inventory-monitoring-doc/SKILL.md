---
name: inventory-monitoring-doc
description: 用於產出庫存監控模組學習/教學文件的 skill。當使用者要求「產出庫存監控學習文件」、「製作庫存管理教學文件」、「依照庫存監控專案產生相似專案文件」，或提到 FR-01 產品管理 + FR-02 庫存監控 時使用。此 skill 會分析既有的 Spring Boot + 多前端（Angular/React/Vite）庫存監控專案，並依照分層架構模式產出逐步教學文件，教讀者從零建立相似專案。
---

# 庫存監控模組學習文件產生器

此 skill 用於產出**繁體中文**、結構化、可跟著動手做的庫存監控模組學習/教學文件。
以 `C:\jscode\庫存監控模組-實作文件.md` 專案為參考基準，確保產出的文件涵蓋相同等級的技術深度與練習內容。

## 目標

當使用者要求產出「相似專案的學習文件」時：

1. 先**分析參考專案**（使用者指定的路徑，或當前的 Spring Boot + 多前端庫存專案）。
2. 從中抽出：技術棧、套件結構、分層架構、實體關聯、查詢技巧、Dashboard 聚合查詢、錯誤處理、三種前端實作、設定檔等重點。
3. 產出一份「從零建立相似專案」的**逐步教學文件**，讓讀者動手實作而非只看程式碼。

## 參考基準專案（庫存監控模組）

以下為參考專案的技術特徵，產出文件時應保持同等深度與風格：

### 後端技術棧
- **Spring Boot 3.2 / Java 17 / Maven**
- 依賴：
  - `spring-boot-starter-web` (REST API)
  - `spring-boot-starter-data-jpa` (JPA + Hibernate)
  - `mysql-connector-j` (runtime)
  - `spring-boot-starter-validation` (Bean Validation)
  - `spring-boot-devtools` (runtime)
  - test：`spring-boot-starter-test`
- 套件結構：`com.classicmodels.inventory` 下分 `controller` / `config` / `model` / `repository` / `service` / `dto` / `exception`
- 分層架構：Controller → Service → Repository → Entity
- 實體設計：
  - `Product` — 對應既有 `products` 表（110 筆資料）
  - `StockThreshold` — 新增安全水位表（1:1 關聯 Product）
  - 使用 `@Table(name=...)` 明確對應資料表、@Column 約束
- Repository 技巧：
  - **Derived Query**：`findByProductLine`、`findByProductVendor`
  - **@Query JPQL**：關鍵字搜尋（LIKE）、低庫存警示（JOIN 子查詢）、Dashboard 統計（GROUP BY + 聚合）
  - **分頁與排序**：可擴充 `Pageable`
- Service：`@Transactional` 交易示範（CRUD、安全水位 upsert）
- Controller：RESTful 風格，統一回傳格式 `ApiResponse<T>`，正確狀態碼（200/201/400/404/500）
- 錯誤處理：`GlobalExceptionHandler` + `ResourceNotFoundException` + `IllegalArgumentException` + Validation
- CORS 設定：支援 Angular (4200)、React (3000)、Vite (5173)
- 設定檔 `application.properties`：MySQL 連線、JPA 設定、ddl-auto=update

### 資料庫設計
- **沿用既有表**：`classicmodels.products` (110 筆真實資料)
- **新增表**：`stock_thresholds` (FK → products.productCode)
  - 欄位：id、product_code (UNIQUE FK)、min_quantity、reorder_quantity、updated_at
  - 預設值：min=200、reorder=500
- 種子資料：5 筆低庫存產品的預設水位設定

### 前端技術棧（三種並行實作）
| 前端 | 框架 | 建構工具 | 語言 | 特色 |
|------|------|---------|------|------|
| Angular | Angular 17 Standalone | Angular CLI | TypeScript | Standalone Component、HttpClient、RxJS |
| React | React 18 + Router v6 | Create React App | TypeScript | Hooks、Axios、Bootstrap 5 |
| Vite React | React 18 + Router v6 | Vite | JavaScript | Vite Proxy、現代建構、ESM |

### 前端核心功能
| Component | 功能 | 共同需求 |
|-----------|------|---------|
| Dashboard | 4 格統計卡片、產品線統計表、緊急補貨清單 | Bootstrap 5 Card/Table/Badge |
| ProductList | 關鍵字搜尋、產品線/供應商篩選、毛利率計算 | 表格篩選、分頁、毛利率 |
| LowStockAlert | 低庫存清單、安全水位 inline 編輯 | 即時編輯、狀態標示 |

---

## 產出文件的固定結構

依下列章節順序產出教學文件（可依主題增減，但架構順序不可亂）：

1. **專案簡介與技術棧**
   - 主題、目標、使用的技術清單、版本、選擇理由表格
2. **環境準備**
   - JDK 17、Maven、MySQL、Node.js、IDE 設定
   - 資料庫建庫（`classicmodels` + `stock_thresholds`）
3. **建立專案骨架**
   - Maven 專案 / `pom.xml` 依賴逐項說明（每個依賴用途與為何需要）
   - 主啟動類 `@SpringBootApplication`
   - 套件目錄結構建立
4. **設定檔**
   - `application.properties` 每個屬性的意義
   - CORS 設定（多前端端口）
5. **資料庫設計**
   - 沿用既有表結構說明
   - 新增表 ER 圖、FK 關聯、索引
   - `data.sql` 種子資料寫法
6. **實體設計（Entity）**
   - 每個實體欄位、`@Column` 約束、關聯註解（@ManyToOne / @OneToOne）
   - 無參數建構子 / Getter/Setter
7. **Repository 層**
   - 從最簡單的 CRUD（JpaRepository 內建）開始
   - 依序教 Derived Query → @Query JPQL → 聚合查詢 → JOIN FETCH（如需要）
   - **每個查詢技巧都要有「重點說明 + 程式碼 + 對應 API 端點」**
8. **DTO 設計**
   - Request/Response DTO、驗證註解、統一回傳格式 `ApiResponse<T>`
9. **Service 層**
   - 交易（@Transactional）概念、readOnly 優化
   - 業務邏輯封裝（CRUD、低庫存查詢、Dashboard 聚合、安全水位 upsert）
   - 私有映射方法（DTO ↔ Entity）
10. **Controller 層**
    - RESTful API 設計、路徑命名慣例（`/api/products`、`/api/thresholds`）
    - 統一回傳格式、正確狀態碼
    - Swagger 註解（可選）
11. **全域例外處理**
    - `@RestControllerAdvice` + 自訂例外 + Validation 錯誤處理
12. **前端實作（三選一或並列）**
    - 專案建立、依賴安裝、目錄結構
    - Model 介面/型別定義
    - Service/Api 層封裝
    - 三大 Component 完整程式碼（TS/JSX/JS 版本）
    - 路由設定、導覽列
13. **API 規格總表**
    - 方法、路徑、說明、對應需求編號
    - 統一回傳/錯誤格式範例
14. **SQL 初始化腳本**
    - 建表語法、FK、預設值、種子資料
15. **執行與驗證**
    - `mvn spring-boot:run`、前端啟動指令
    - Swagger/Postman/cURL 驗證步驟
16. **練習題 / 學習檢查點**
    - 出 3~5 道循序漸進的練習題，答案留白供讀者實作

---

## 產出規則

- **全程使用繁體中文**，專有名詞（如 Derived Query、JPQL、GROUP BY、Dashboard、Threshold）可保留英文。
- 每個主題依循「**先講概念 → 再給程式碼 → 最後講解程式碼**」的三段式寫法。
- 程式碼需**完整可執行**，不可用省略號含糊帶過。
- 標註「執行結果 / 預期輸出」，讓讀者能自行驗證。
- 重點（陷阱、注意事項）用 `> ⚠️` 引用塊標示。
- 練習題需具體、有明確完成標準，並標示「難度：★ ~ ★★★」。
- **三種前端版本並列展示**，讓讀者可選擇學習目標框架。

---

## 執行流程

1. **確認輸入**：
   - 使用者是否提供「參考專案路徑」？有 → 完整讀取該專案的 pom.xml、所有 java 檔、前端原始碼、resources 設定。
   - 無 → 以 `C:\jscode\庫存監控模組-實作文件.md` 所描述專案作為參考基準。
   - 確認「主題」：與參考專案相同，或使用者指定的新主題（如訂單庫存、倉儲管理）。

2. **分析**：列出該專案的技術重點清單（依賴、架構、查詢技巧、API 清單、前端架構），作為文件的素材。

3. **確認輸出檔名**：依主題命名（例如 `inventory-monitoring-guide.md`），與使用者確認後寫入檔案。

4. **產出文件**：依「產出文件的固定結構」撰寫，一次完成，避免分段輸出。

---

## 驗證品質

產出完成後自檢：

- [ ] 是否涵蓋分層架構每一層（Controller/Service/Repository/Entity/DTO/Exception/Config）？
- [ ] 每個查詢技巧是否都有「概念 + 程式碼 + API 端點」？
- [ ] 後端程式碼是否完整可執行、無明顯缺漏？
- [ ] 三種前端版本是否都有完整實作（Model/Service/Component/Routing）？
- [ ] 是否有執行與驗證章節（含啟動指令、API 驗證步驟）？
- [ ] 是否有循序漸進的練習題？
- [ ] 程式碼區塊是否標註語言（```java、```typescript、```jsx、```javascript、```sql）？