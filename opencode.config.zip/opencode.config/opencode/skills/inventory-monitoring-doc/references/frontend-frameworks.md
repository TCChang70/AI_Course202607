# 前端三框架實作對照指南

## 專案啟動對照

| 項目 | Angular 17 | React (CRA) | Vite React |
|------|-----------|-------------|-----------|
| 建立指令 | `ng new inventory-frontend --standalone --routing` | `npx create-react-app inventory-react --template typescript` | `npm create vite@latest inventory-vite-react -- --template react` |
| 啟動指令 | `ng serve` | `npm start` | `npm run dev` |
| 預設端口 | 4200 | 3000 | 5173 |
| 建構工具 | Angular CLI (Webpack) | react-scripts (Webpack) | Vite (esbuild/Rollup) |
| 型別檢查 | TypeScript (內建) | TypeScript (內建) | 無 (純 JS) / 需額外加裝 |

---

## 專案目錄結構對照

### Angular 17 (Standalone)
```
src/app/
├── app.component.ts         # 根元件 + 導覽列
├── app.routes.ts            # 路由設定
├── models/
│   ├── product.model.ts
│   └── stock-summary.model.ts
├── services/
│   └── product.service.ts
└── components/
    ├── dashboard/
    ├── product-list/
    └── low-stock-alert/
```

### React (CRA + TypeScript)
```
src/
├── index.tsx
├── App.tsx                  # 根元件 + 路由
├── models/
│   ├── product.ts
│   └── stock-summary.ts
├── services/
│   └── productService.ts
├── pages/
│   ├── Dashboard.tsx
│   ├── ProductList.tsx
│   ├── ProductDetail.tsx
│   └── LowStockAlert.tsx
└── components/
    └── Navbar.tsx
```

### Vite React (JavaScript)
```
src/
├── main.jsx
├── App.jsx                  # 根元件 + 路由
├── api/
│   └── productService.js
├── pages/
│   ├── Dashboard.jsx
│   ├── ProductList.jsx
│   ├── ProductDetail.jsx
│   └── LowStockAlert.jsx
└── components/
    └── Navbar.jsx
```

---

## 核心概念對照表

| 概念 | Angular | React (TSX) | Vite React (JSX) |
|------|---------|-------------|------------------|
| **元件定義** | `@Component({...}) export class` | `function Component() { return <div/> }` | 同 React |
| **狀態管理** | `signal()` / `useState()` (實驗性) | `useState()` | `useState()` |
| **副作用** | `effect()` / `ngOnInit` | `useEffect(() => {...}, [deps])` | 同 React |
| **模板語法** | `*ngIf` / `*ngFor` / `[()]` | `{condition && <Comp/>}` / `{list.map()}` | 同 React |
| **雙向綁定** | `[(ngModel)]` | `value={state} onChange={e=>setState(e.target.value)}` | 同 React |
| **樣式** | `styles: []` / `.component.css` | `import './Component.css'` / `className` | 同 React |
| **依賴注入** | `constructor(private svc: Service)` | `import { func } from '../services'` | 同 React |
| **HTTP 呼叫** | `HttpClient` + `Observable` + `pipe(map)` | `axios` + `async/await` | 同 React |
| **路由參數** | `route.snapshot.paramMap.get('id')` | `useParams()` | `useParams()` |
| **程式化導航** | `router.navigate(['/path'])` | `useNavigate()` | `useNavigate()` |
| **路由定義** | `Routes` 陣列 + `provideRouter` | `<Routes><Route path="..." element={<Comp/>}/></Routes>` | 同 React |

---

## 三框架關鍵程式碼對照

### 1. HTTP 服務層

#### Angular (HttpClient + RxJS)
```typescript
@Injectable({ providedIn: 'root' })
export class ProductService {
  private apiUrl = 'http://localhost:8080/api';
  constructor(private http: HttpClient) {}

  getProducts(filters?: { productLine?: string; vendor?: string; keyword?: string }): Observable<Product[]> {
    let params = new HttpParams();
    if (filters?.productLine) params = params.set('productLine', filters.productLine);
    // ...
    return this.http.get<ApiResponse<Product[]>>(`${this.apiUrl}/products`, { params })
               .pipe(map(res => res.data));
  }
}
```

#### React (Axios + async/await)
```typescript
const api = axios.create({ baseURL: 'http://localhost:8080/api' });

async function unwrap<T>(promise: Promise<{ data: ApiResponse<T> }>): Promise<T> {
  const res = await promise;
  return res.data.data;
}

export async function getProducts(filters?: { productLine?: string; vendor?: string; keyword?: string }): Promise<Product[]> {
  const params: Record<string, string> = {};
  if (filters?.productLine) params.productLine = filters.productLine;
  // ...
  return unwrap<Product[]>(api.get('/products', { params }));
}
```

#### Vite React (Axios + Vite Proxy)
```javascript
// vite.config.js 已設定 proxy: { '/api': { target: 'http://localhost:8080', changeOrigin: true } }
const API_URL = '';  // 使用 Vite proxy，無需完整 URL

const api = axios.create({ baseURL: API_URL });

export async function getProducts(filters = {}) {
  const params = {};
  if (filters.productLine) params.productLine = filters.productLine;
  // ...
  const res = await api.get('/api/products', { params });
  return res.data.data;
}
```

---

### 2. 元件 + 模板

#### Angular (Standalone Component)
```typescript
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="dashboard-container">
      <h2>庫存監控儀表板</h2>
      <div class="summary-cards">
        <div class="card">
          <div class="card-value">{{ totalProducts }}</div>
          <div class="card-label">總產品數</div>
        </div>
        <!-- ... -->
      </div>
      <table class="data-table">
        <tr *ngFor="let s of summaries">
          <td>{{ s.productLine }}</td>
          <td class="text-center">{{ s.productCount }}</td>
        </tr>
      </table>
    </div>
  `,
  styles: [`.card { ... }`]
})
export class DashboardComponent implements OnInit {
  summaries: StockSummary[] = [];
  constructor(private productService: ProductService) {}
  ngOnInit() {
    this.productService.getDashboardSummary().subscribe(data => this.summaries = data);
  }
}
```

#### React (TypeScript + Hooks)
```tsx
function Dashboard() {
  const [summaries, setSummaries] = useState<StockSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboardSummary()
      .then(setSummaries)
      .finally(() => setLoading(false));
  }, []);

  const totalProducts = summaries.reduce((s, r) => s + r.productCount, 0);

  if (loading) return <div className="p-4">載入中...</div>;

  return (
    <div className="container py-4">
      <h2>庫存監控儀表板</h2>
      <div className="row g-3 mb-4">
        <div className="col-md-3">
          <div className="card text-center shadow-sm">
            <div className="card-body">
              <h3 className="text-primary">{totalProducts}</h3>
              <p className="text-muted mb-0">總產品數</p>
            </div>
          </div>
        </div>
        {/* ... */}
      </div>
      <table className="table table-bordered">
        <tbody>
          {summaries.map(s => (
            <tr key={s.productLine}>
              <td>{s.productLine}</td>
              <td className="text-center">{s.productCount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

#### Vite React (JavaScript)
```jsx
function Dashboard() {
  const [summaries, setSummaries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboardSummary()
      .then(setSummaries)
      .finally(() => setLoading(false));
  }, []);

  const totalProducts = summaries.reduce((s, r) => s + r.productCount, 0);

  if (loading) return <div className="p-4">載入中...</div>;

  return (
    <div className="container py-4">
      <h2>庫存監控儀表板</h2>
      {/* Bootstrap 卡片與表格，同 React 版 */}
    </div>
  );
}
```

---

### 3. 路由設定

#### Angular (app.routes.ts)
```typescript
export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'products', component: ProductListComponent },
  { path: 'products/:code', component: ProductDetailComponent },
  { path: 'low-stock', component: LowStockAlertComponent }
];

// main.ts
bootstrapApplication(AppComponent, {
  providers: [provideRouter(routes), provideHttpClient()]
});
```

#### React (App.tsx)
```tsx
import { Routes, Route, Navigate } from 'react-router-dom';

function App() {
  return (
    <>
      <Navbar />
      <main style={{ maxWidth: 1200, margin: '0 auto' }}>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/products/:id" element={<ProductDetail />} />
          <Route path="/low-stock" element={<LowStockAlert />} />
        </Routes>
      </main>
    </>
  );
}
```

---

### 4. 導覽列與 NavLink

| 框架 | 導覽元件 | Active 樣式判斷 |
|------|---------|----------------|
| Angular | `<a routerLink="/dashboard" routerLinkActive="active">` | `routerLinkActive` 自動加 class |
| React | `<NavLink to="/dashboard" className={({isActive}) => isActive ? 'active' : ''}>` | `NavLink` 的 `isActive` 回呼 |
| Vite React | 同 React | 同 React |

> ⚠️ **重點**：`to="/"` 的 NavLink **必須加 `end` 屬性**，否則所有路徑都會匹配。

---

### 5. Bootstrap 5 整合

| 框架 | 安裝方式 | 匯入方式 |
|------|---------|---------|
| Angular | `npm install bootstrap` | `angular.json` styles/scripts 或 `styles.css` `@import` |
| React CRA | `npm install bootstrap` | `index.tsx` `import 'bootstrap/dist/css/bootstrap.min.css'` |
| Vite React | `npm install bootstrap` | `main.jsx` `import 'bootstrap/dist/css/bootstrap.min.css'` |

---

## 三框架共同注意事項

| 項目 | 說明 |
|------|------|
| **API 基礎 URL** | Angular: `http://localhost:8080/api` / React: 同 / Vite: 空字串 (使用 Proxy) |
| **CORS** | 後端需允許 4200/3000/5173 三個端口 |
| **型別定義** | Angular/React TS: `.ts` interface / Vite JS: 不需型別 |
| **CSS 類名** | Angular: `class` / React: `className` |
| **事件綁定** | Angular: `(click)="fn()"` / React: `onClick={fn}` |
| **條件渲染** | Angular: `*ngIf` / React: `condition && <Comp/>` 或三元運算子 |
| **列表渲染** | Angular: `*ngFor="let item of list"` / React: `{list.map(item => <Comp key={item.id} />)}` |
| **表單輸入** | Angular: `[(ngModel)]="value"` / React: `value={state} onChange={e=>setState(e.target.value)}` |

---

## 選擇建議

| 學習目標 | 推薦框架 |
|----------|---------|
| 企業級專案、強型別、大型團隊 | **Angular 17 Standalone** |
| 現代 React 開發、TypeScript、生態系豐富 | **React + TypeScript (CRA/Vite)** |
| 快速原型、學習 React 基礎、無型別負擔 | **Vite + React (JavaScript)** |
| 想三者都會 | **先學 React (TS)** → 再對照 Angular / Vite JS 差異 |