# 後端分層架構實作指南

## 架構概覽

```
Controller → Service → Repository → Entity
     ↑           ↑            ↑         ↑
  HTTP/JSON  @Transactional  JPA/     @Entity
  統一格式      交易管理     Hibernate  Table映射
```

---

## 1. Controller 層

### 職責
- 接收 HTTP 請求、參數驗證
- 呼叫 Service，不包含業務邏輯
- 回傳統一格式 `ApiResponse<T>`
- 正確 HTTP 狀態碼

### 關鍵註解
| 註解 | 用途 |
|------|------|
| `@RestController` | 回傳 JSON，等同 `@Controller + @ResponseBody` |
| `@RequestMapping("/api/products")` | 基礎路徑 |
| `@GetMapping`/`@PostMapping`/... | HTTP 方法對應 |
| `@PathVariable` | 路徑變數綁定 |
| `@RequestParam` | 查詢參數綁定（required=false 為選填） |
| `@RequestBody` | JSON Body 綁定到 DTO |
| `@Valid` | 觸發 Bean Validation |

### 統一回傳格式
```java
public class ApiResponse<T> {
    private boolean success;
    private String message;
    private T data;

    public static <T> ApiResponse<T> ok(T data) { ... }
    public static <T> ApiResponse<T> ok(String message, T data) { ... }
}
```

### 狀態碼規範
| 情境 | 狀態碼 | 範例 |
|------|--------|------|
| 查詢成功 | 200 | GET /api/products |
| 建立成功 | 201 | POST /api/products |
| 更新成功 | 200 | PUT /api/products/{id} |
| 刪除成功 | 200/204 | DELETE /api/products/{id} |
| 參數錯誤 | 400 | @Valid 失敗、IllegalArgumentException |
| 找不到資源 | 404 | ResourceNotFoundException |
| 伺服器錯誤 | 500 | 未捕獲例外 |

---

## 2. Service 層

### 職責
- 業務邏輯核心
- 交易管理（`@Transactional`）
- Repository 協調、DTO ↔ Entity 轉換
- 例外拋出（ResourceNotFoundException、IllegalArgumentException）

### 關鍵註解
| 註解 | 用途 |
|------|------|
| `@Service` | 標記為 Service Bean |
| `@Transactional` | 方法層級交易（預設 readOnly=false） |
| `@Transactional(readOnly = true)` | 唯讀查詢優化（Hibernate 不追蹤快照） |

### 交易原則
- **查詢方法**：加 `@Transactional(readOnly = true)` 提升效能
- **寫入方法**：預設 `@Transactional`（rollback on RuntimeException）
- **跨表操作**：單一方法內完成多個 Repository 操作

### DTO ↔ Entity 映射
```java
// 私有方法封裝映射邏輯
private Product mapToEntity(ProductDTO dto) {
    Product p = new Product();
    p.setProductCode(dto.getProductCode());
    // ... 其他欄位
    return p;
}
```

---

## 3. Repository 層

### 繼承體系
```java
public interface ProductRepository extends JpaRepository<Product, String> { }
```
- `JpaRepository<T, ID>` 提供：`save`、`findById`、`findAll`、`deleteById`、`existsById`、`count`

### 查詢技巧進階順序

| 階段 | 技巧 | 範例 | 適用情境 |
|------|------|------|----------|
| 1 | **Derived Query** | `findByProductLine(String)` | 簡單條件、命名慣例 |
| 2 | **@Query JPQL** | `@Query("SELECT p FROM Product p WHERE ...")` | 複雜條件、JOIN、聚合 |
| 3 | **@Modifying** | `@Modifying @Query("UPDATE ...")` | 批次更新/刪除 |
| 4 | **Native Query** | `@Query(value="SELECT * FROM ...", nativeQuery=true)` | 資料庫特有功能、效能調校 |
| 5 | **JOIN FETCH** | `@Query("SELECT p FROM Product p JOIN FETCH p.category")` | 解決 N+1 問題 |

### JPQL 重點
- 使用 Entity 名稱與屬性名（非資料表/欄位名）
- 參數綁定：`:paramName` + `@Param("paramName")`
- 聚合函數：`COUNT`、`SUM`、`AVG`、`MIN`、`MAX`
- 分組：`GROUP BY`、`HAVING`
- 排序：`ORDER BY`（或配合 `Sort`/`Pageable`）

### 常見 JPQL 模式
```java
// 關鍵字搜尋（不分大小寫）
@Query("SELECT p FROM Product p WHERE LOWER(p.productName) LIKE LOWER(CONCAT('%', :keyword, '%'))")
List<Product> searchByKeyword(@Param("keyword") String keyword);

// 子查詢比較
@Query("SELECT p FROM Product p WHERE p.quantityInStock < (SELECT COALESCE(st.minQuantity, 200) FROM StockThreshold st WHERE st.productCode = p.productCode)")
List<Product> findLowStockProducts();

// 聚合統計
@Query("SELECT p.productLine, SUM(p.quantityInStock), COUNT(p), MIN(p.quantityInStock) FROM Product p GROUP BY p.productLine ORDER BY SUM(p.quantityInStock) DESC")
List<Object[]> getStockSummaryByProductLine();
```

---

## 4. Entity 設計規範

### 基本結構
```java
@Entity
@Table(name = "products")  // 明確對應資料表
public class Product {
    @Id
    @Column(name = "productCode", length = 15)
    private String productCode;

    @Column(name = "productName", nullable = false, length = 70)
    private String productName;
    // ...
}
```

### 關聯對應
| 關聯 | 註解組合 | 說明 |
|------|----------|------|
| @OneToOne | `@OneToOne` + `@JoinColumn` | 雙向/單向 1:1 |
| @ManyToOne | `@ManyToOne` + `@JoinColumn` | 多方擁有 FK |
| @OneToMany | `@OneToMany(mappedBy = "...")` | 一方維護關聯 |
| @ManyToMany | `@ManyToMany` + `@JoinTable` | 多對多中間表 |

### 避免序列化循環
```java
// 父實體
@OneToMany(mappedBy = "product")
@JsonIgnoreProperties("product")  // 忽略反向引用
private List<StockThreshold> thresholds;

// 子實體
@ManyToOne
@JoinColumn(name = "product_code")
@JsonIgnoreProperties("thresholds")
private Product product;
```

### 生命週期回呼
```java
@PrePersist
@PreUpdate
public void onUpdate() {
    this.updatedAt = LocalDateTime.now();
}
```

---

## 5. DTO 與驗證

### Bean Validation 常用註解
| 註解 | 適用型別 | 說明 |
|------|----------|------|
| `@NotBlank` | String | 不為 null、trim 後不為空 |
| `@NotNull` | 任意 | 不為 null |
| `@Size(min=, max=)` | String/Collection/Map/Array | 長度範圍 |
| `@Min`/`@Max` | 數值 | 數值範圍 |
| `@DecimalMin`/`@DecimalMax` | BigDecimal/double/float | 浮點數範圍 |
| `@Email` | String | Email 格式 |
| `@Pattern` | String | 正則表達式 |

### Controller 觸發驗證
```java
@PostMapping
public ResponseEntity<ApiResponse<Object>> create(@Valid @RequestBody ProductDTO dto) {
    // 驗證失敗會拋出 MethodArgumentNotValidException
    // 由 GlobalExceptionHandler 捕獲處理
}
```

---

## 6. 例外處理架構

### 自訂例外
```java
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) { super(message); }
}
```

### GlobalExceptionHandler
```java
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(ResourceNotFoundException ex) {
        return buildError(HttpStatus.NOT_FOUND, "NOT_FOUND", ex.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleBadRequest(IllegalArgumentException ex) {
        return buildError(HttpStatus.BAD_REQUEST, "BAD_REQUEST", ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException ex) {
        Map<String, String> fieldErrors = new HashMap<>();
        for (FieldError fe : ex.getBindingResult().getFieldErrors()) {
            fieldErrors.put(fe.getField(), fe.getDefaultMessage());
        }
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("errorCode", "VALIDATION_ERROR");
        body.put("errors", fieldErrors);
        return ResponseEntity.badRequest().body(body);
    }

    private ResponseEntity<Map<String, Object>> buildError(HttpStatus status, String errorCode, String message) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("errorCode", errorCode);
        body.put("message", message);
        return ResponseEntity.status(status).body(body);
    }
}
```

### 錯誤回傳格式
```json
// 404
{ "success": false, "errorCode": "NOT_FOUND", "message": "Product not found: S99_9999" }

// 400
{ "success": false, "errorCode": "BAD_REQUEST", "message": "Quantity values must be greater than 0" }

// 400 Validation
{ "success": false, "errorCode": "VALIDATION_ERROR", "errors": { "productCode": "must not be blank" } }
```

---

## 7. CORS 設定

```java
@Configuration
public class CorsConfig {
    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of(
            "http://localhost:4200",  // Angular
            "http://localhost:3000",  // React CRA
            "http://localhost:5173"   // Vite
        ));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", config);
        return new CorsFilter(source);
    }
}
```

---

## 8. application.properties 關鍵設定

```properties
# 伺服器
server.port=8080

# MySQL
spring.datasource.url=jdbc:mysql://localhost:3306/classicmodels?useSSL=false&serverTimezone=Asia/Taipei&characterEncoding=UTF-8
spring.datasource.username=root
spring.datasource.password=your_password
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# JPA/Hibernate
spring.jpa.database-platform=org.hibernate.dialect.MySQLDialect
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=false
spring.jpa.properties.hibernate.format_sql=true

# 日誌
logging.level.com.classicmodels=INFO
```

> ⚠️ **注意**：`ddl-auto=update` 會自動建立/更新表結構，生產環境建議用 `validate` + Flyway/Liquibase 遷移腳本。