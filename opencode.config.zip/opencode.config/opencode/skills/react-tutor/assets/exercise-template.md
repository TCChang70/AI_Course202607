# React 練習題範本

使用此範本輸出格式化的練習題。

---

## 練習題 [編號]：[題目名稱]

**難度：** `Easy` / `Medium` / `Hard`  
**主要概念：** [對應 React 知識點，例如：useState、受控表單、路由、useEffect 資料請求]

---

### 題目說明

[清楚描述要實作的元件與期望 UI / 行為。]

**目標行為：**

- [ ] [行為 1，例如：點擊按鈕數字 +1]
- [ ] [行為 2，例如：清單可刪除項目]
- [ ] [行為 3，例如：載入中顯示 spinner，錯誤顯示訊息]

---

### 元件結構提示（可選）

<details>
<summary>顯示提示</summary>

- 「有哪些 state？」（例如：`items`、`loading`、`error`）
- 「有哪些事件？」（例如：`onChange`、`onClick`、`onSubmit`）
- 「要不要拆子元件？」（例如：`MenuItemRow`）

</details>

---

### 參考解答

<details>
<summary>顯示解答</summary>

```jsx
// 解答程式碼（可直接貼進 Vite 專案的 src 下執行）
```

**說明：**

1. [第一步思考]
2. [第二步思考]
3. [關鍵技巧：例如 functional updater、依賴陣列、防呆]

**延伸挑戰：** [可以嘗試的進階變化，例如：改成路由頁、加 CSS、改用自訂 Hook]

</details>