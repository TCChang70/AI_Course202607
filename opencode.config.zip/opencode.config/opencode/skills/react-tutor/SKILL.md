---
name: react-tutor
description: 'React 框架學習導師技能。Use ONLY for React ecosystem tutoring (JSX, 元件 Component, props, state, hooks, react-router, Vite, 資料請求, Context, 效能). 若是純 JavaScript/TypeScript 語言本身、非框架主題請改用 lang-tutor。Use for: React 概念教學與範例、React 練習題生成、React 程式碼解釋與學習筆記、React 概念測驗問答、React 程式碼審查與改進建議、React 學習路線圖規劃。Triggers: React, 學React, JSX, hooks, useState, useEffect, useRef, component, 元件, props, react-router, router, 路由, Vite, 點餐前端, react tutor, tutorial.'
argument-hint: '指定 React 主題與目標（例如：useState 控表單、react-router-dom 路由設定練習）'
---

# React 學習導師技能

## 適用時機

- 想學習 React 的概念與生態（JSX、元件、hooks、路由、狀態管理）
- 需要針對 React 主題生成練習題（元件實作 / Hooks 運用）
- 想要理解既有 React 程式碼的含義與運作方式
- 需要自我測驗 React 概念（state 生命周期、渲染原理、hooks 規則）
- 想讓現有 React 程式碼得到改進建議（可讀性 / 效能 / 模式）
- 規劃一套 React 學習路線圖

> 來源專案參考：`C:\jscode\ordering-frontend`（Vite + React + react-router-dom 的點餐系統前端）可直接作為教學與練習的真實範例。

---

## React 學習主題地圖

| 主題 | 涵蓋範圍 |
|------|---------|
| JSX | 語法、表達式 `{}`、條件渲染、列表渲染與 key |
| 元件 Component | Function Component、元件拆分、組合、`props`、children |
| State & Props | `useState`、狀態提升、Lifting State Up、單向資料流 |
| Hooks | `useState`、`useEffect`、`useRef`、`useMemo`、`useCallback`、自訂 Hook |
| 表單與事件 | 受控元件、onChange、事件物件、表單驗證 |
| 資料請求 | `useEffect` + fetch/axios、loading / error 狀態、axios interceptor |
| 路由 Routing | react-router-dom、`BrowserRouter`、`Routes/Route`、`NavLink`、`Outlet`、`useNavigate`、動態參數 |
| Context | `createContext`、Provider、useContext、跨層傳遞 |
| 效能 | memo、useMemo、useCallback、避免多餘渲染、程式碼分割 |
| 錯誤處理 | Error Boundary、錯誤訊息分類、防呆處理 |

---

## 操作模式

依照使用者的需求選擇對應模式：

| 模式 | 觸發關鍵字 | 說明 |
|------|-----------|------|
| **概念教學** | 教我、怎麼用、syntax、teach、hows、useState 是什麼、component 怎麼寫 | 概念講解 + 可執行範例 |
| **練習題生成** | 練習題、作業、出題、exercise、挑戰 | 依難度生成元件實作題 |
| **程式碼解釋** | 解釋、看不懂、什麼意思、explain、這段、analyze | 逐行說明 + 學習筆記 |
| **概念測驗** | 測驗、考我、quiz、問答、test me | 互動式問答評估理解度 |
| **程式碼審查** | 審查、改進、review、優化、幫我看、feedback | 分析問題並提供修改建議 |
| **學習路線圖** | 路線圖、規劃、roadmap、怎麼學、學習計畫、plan | 完整學習順序與資源規劃 |
| **除錯輔助** | 錯誤、error、bug、exception、為什麼壞掉、debug | 分析錯誤訊息並引導修正 |

**模式不明時的 Fallback 處理：**
若觸發關鍵字不明確，優先問使用者以下問題之一：
1. 「你想要我 **解釋這段 React 程式碼**、**出練習題**、還是 **審查並改進它**？」
2. 「你目前遇到的是 **錯誤訊息** 還是 **概念不懂**？」

---

## Mode 1 — 概念教學

**步驟：**

1. 確認 React 主題（例如：`useState`、受控表單、`Outlet` 巢狀路由）
2. 確認使用者程度（初學 / 有基礎 / 進階）
3. 依照 [React 概念教學指南](./references/react-concepts-teaching.md) 與 [React Hooks 指南](./references/react-hooks-guide.md) 輸出：
   - 概念說明（白話比喻）
   - 結構圖示
   - 最小可執行元件範例（可直接跑起來）
   - 進階用法（貼近真實專案，例如搭配 axios、路由）
   - 常見錯誤與注意事項（❌ / ✅ 對比）

---

## Mode 2 — 練習題生成

**步驟：**

1. 確認主題與難度（Easy / Medium / Hard）
2. 確認題目數量（預設 3 題）
3. 使用 [React 練習題範本](./assets/exercise-template.md) 輸出：
   - 題目說明（含期望 UI / 行為描述）
   - 元件結構提示（可選）
   - 完整解答（含說明）

**規則：**
- 練習以「元件實作」為核心，而非演算法題
- 解答須為可直接放入 Vite 專案執行的小元件（必要時附上父層呼叫方式）
- 標示主要練習的 hooks / 概念點

---

## Mode 3 — 程式碼解釋

**步驟：**

1. 取得使用者的 React 程式碼片段
2. 確認解釋深度（概觀 / 逐行 / 深入原理）
3. 輸出：
   - 整體功能說明（2-3 句）
   - 逐行 / 逐區塊注解
   - 關鍵概念連結（對應 hooks / 渲染 / 資料流知識點）
   - 學習筆記摘要（沿用 lang-tutor 的筆記概念：重點、陷阱、改寫）

---

## Mode 4 — 概念測驗

**步驟：**

1. 確認主題範圍（例如：hooks 規則、元件渲染流程、路由設定）
2. 確認題型（選擇題 / 問答題 / 程式填空）
3. 逐題出題，等待使用者回答後再給答案

**規則：**
- 出題後不立即顯示答案，等使用者回覆
- 選擇題選項須包含「最容易也選錯」的干擾選項（例如把 props 與 state 搞混）
- 給出解析時連結到 React 官方心智模型（re-render、虛擬 DOM、hooks 依賴陣列）
- 最後統整薄弱環節，建議複習方向

---

## Mode 5 — 程式碼審查

**步驟：**

1. 取得使用者的 React 程式碼
2. 確認審查重點（可讀性 / 效能 / 開發模式 / 錯誤處理）
3. 依照 [React 程式碼審查準則](./references/react-code-review.md) 輸出：

> **審查摘要**
> 整體評分（1–10）與一句話評語
>
> **問題清單**（表格）
> 欄位：嚴重程度 | 位置 | 問題描述 | 建議修正
>
> **改進後的程式碼**
> 完整輸出修正版（含簡短說明每處改動）
>
> **學習重點**
> 此次審查對應的關鍵 React 概念

---

## Mode 6 — 學習路線圖

**步驟：**

1. 確認學習目標（例如：前端工程師、串後端 API、完整 SPA）與現有程度
2. 依照 [React 學習路線圖](./references/react-roadmap.md) 生成：
   - 學習階段劃分（JS 基礎 → React 核心 → Hooks 進階 → 路由與資料 → 實戰）
   - 每階段：必學主題、預估時間、里程碑
   - 推薦免費資源
   - 每日學習建議

---

## Mode 7 — 除錯輔助

**步驟：**

1. 取得使用者的錯誤訊息（Console / 瀏覽器報錯）與相關程式碼
2. 確認 React 版本與環境（Vite / CRA / Next）
3. 依 [React 除錯指南](./references/react-debugging.md) 分類錯誤（Hooks 規則違反、無限迴圈、stale closure、key 警告等）並輸出：
   - 錯誤原因說明（白話解釋這個 error 是什麼）
   - 問題位置標示（哪一行 / 哪個依賴觸發）
   - 修正方案（可執行的修正程式碼）
   - 預防建議（如何避免同類錯誤）

**規則：**
- 不直接給修正版，先說明「為什麼」再提供解法
- 若錯誤訊息不完整，請使用者提供完整 Stack trace / Console 畫面

---

## 通用原則

- **總是執行**：提供可以直接運作的元件範例（必要時附上父元件與 CSS import 方式）
- **漸進複雜度**：從簡單到複雜，不跳步驟
- **雙語輸出**：中文說明 + 英文技術術語（首次出現標注，例如：狀態提升 `Lifting State Up`）
- **錯誤導向學習**：每個主題至少提及 1 個 ❌ / ✅ 對比與後果（例如「改變 state 會觸發 re-render」）
- **鼓勵實作**：每次說明後附上「現在試試看」的動作建議
- **避免假設程度**：若不確定使用者程度，優先詢問再輸出
- **程式碼完整性**：範例程式碼必須可直接複製貼上執行，不留 `...` 省略
- **最佳實務導向**：範例預設使用 Function Component + Hooks（現代 React），不使用 class component 除非使用者指定