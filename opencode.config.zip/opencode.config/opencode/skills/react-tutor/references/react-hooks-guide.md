# React Hooks 指南

## 使用原則

- **呼叫位置**：只能在元件或自訂 Hook「最上層」呼叫，不能寫在 if / for / 巢狀函式內。
- **命名**：Hook 一律 `use` 開頭，包括自訂 Hook（例：`useMenu`、`useLocalStorage`）。
- **依賴意識**：`useEffect` / `useMemo` / `useCallback` 都要想清楚依賴陣列。
- **信任心智模型**：`state 改變 → 元件 re-render → 重新執行元件函式`。

---

## useState

| 問題 | 解法 |
|------|------|
| 要連加多次新值 | 用 functional updater：`setCount((c) => c + 1)` |
| 更新多欄位表單 | 用展開保留其他欄位：`setForm((f) => ({ ...f, [key]: v }))` |
| 修改陣列 / 物件不生效 | 產生「新的」值，不原地修改：`setCart((c) => [...c, item])` |
| 兩個元件要共用 state | 狀態提升到最近的共同父元件 |

**陷阱：**
```jsx
// ❌ setCount(count + 1) 連點三次可能只加 1（批次 + 閉包）
// ✅ setCount((c) => c + 1) 依站前值計算
```

---

## useEffect

決定「要不要跑」的重點是依賴陣列：

| 依賴寫法 | 執行時機 | 常見使用 |
|---------|---------|---------|
| 不帶第三參數（無陣列） | 每次渲染後 | 通常不需要，避免 |
| `[]` | 掛載後一次、卸載前 cleanup | 載入資料、訂閱事件 |
| `[dep]` | dep 變更後 | 依某值重新計算 / 請求 |

**cleanup 範例：**
```jsx
useEffect(() => {
  const t = setTimeout(() => setLoading(false), 1000)
  return () => clearTimeout(t) // 卸載或重跑前清除
}, [])
```

**陷阱：**
- 依賴陣列漏掉變數 → stale closure（拿舊值）
- 在 effect 內 setState 卻沒有條件 → 無限重渲染迴圈（見除錯指南）

---

## useRef

| 用途 | 說明 |
|------|------|
| 存取 DOM | `inputRef.current.focus()`（需 `ref={inputRef}`） |
| 存不會觸發 re-render 的「暫時值 / 舊值」 | `ref.current` 改了畫面不會重畫 |
| 保存前一個 state | 搭配 effect 比較 `ref.current !== 新值` |

---

## useMemo / useCallback

- **useMemo**：記住「花錢運算的結果」，依賴不變就不重算。
- **useCallback**：記住「函式」，避免子元件因 props 函式每次重建而多餘 re-render。
- 別過度使用；要先有**可量測的效能問題**再用。

```jsx
const total = useMemo(
  () => cart.reduce((s, x) => s + x.unitPrice * x.quantity, 0),
  [cart],
)
```

---

## 自訂 Hook

把「有狀態的邏輯」抽出來重用，條件是名稱 `use` 開頭、內部可呼叫其他 hooks。

```jsx
function useMenu(fetcher) {
  const [items, setItems] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetcher()
      .then(setItems)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [fetcher])

  return { items, error, loading }
}
```

---

## 順序陷阱建議

| 新手常犯 | 建議 |
|---------|------|
| 依賴陣列圖方便不放 | 用 `useEffect(() => {...}, [dep])` 明確寫出 |
| hooks 屬性對應不上 | 用 ESLint `react-hooks/exhaustive-deps` 檢查 |
| 大量 props 一層層傳 | 明顯穿透時再用 Context 或組合 props |