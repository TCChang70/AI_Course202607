# React 學習路線圖指南

## 路線圖輸出結構

1. **學習目標確認** — 目標（SPA / 全端 / 純前端）+ 現有前端經驗
2. **路線圖總覽** — 5 個階段的視覺化呈現
3. **各階段詳情** — 主題清單、預估時間、里程碑與驗收小專案
4. **推薦資源** — 免費資源為主
5. **每日學習建議** — 依可用時間調整

---

## 階段 0 — 前置準備（可選，若 JS 不熟）

- JavaScript ES6+ 基礎（`const`/`let`、箭頭函式、陣列方法 `map/filter/reduce`、解構、展開運算子、`async/await`）
- **可以略過**：若已能讀懂 `C:\jscode\ordering-frontend\src` 內的程式碼，可直接進階段 1
- **里程碑**：能看懂的簡單 JS 程式

---

## 階段 1 — React 核心（2-3 週）

- JSX 語法與 `{ }` 表達式
- Function Component 與 props
- `useState` 與事件處理
- 條件渲染、列表渲染與 key
- 提升狀態（Lifting State Up）、受控表單
- **里程碑**：做一個待辦清單（新增 / 刪除 / 完成切換）

---

## 階段 2 — 效果與資料（2 週）

- `useEffect`（依賴陣列、cleanup）
- `useRef`（DOM 存取、計時器）
- 資料請求三態（loading / error / data）
- fetch 或 axios 基本串接
- **里程碑**：串一個公開 API（如菜單），顯示並可搜尋
- 練功用專案：`C:\jscode\ordering-frontend` 的 MenuManager 頁面

---

## 階段 3 — 路由與多頁（1-2 週）

- react-router-dom：`BrowserRouter`、`Routes/Route`
- `NavLink`、巢狀路由與 `Outlet`
- `useNavigate`、`useParams`、動態參數
- 404 兜底與路由拆分
- **里程碑**：做出含儀表板 / 列表 / 詳情的三頁 App
- 練習參考：`ordering-frontend` 的 App.jsx 與 Layout.jsx

---

## 階段 4 — 進階模式（2-3 週）

- `useMemo` / `useCallback` 與 re-render 原理
- Context（跨層傳遞、主題、登入狀態）
- 自訂 Hook（抽出可重用邏輯）
- 錯誤處理與 Error Boundary、表單驗證
- JSX 元件組合模式（children、render props 概念）
- **里程碑**：把一個中小型元件重構為自訂 Hook + 拆分元件

---

## 階段 5 — 實戰整合（依目標）

- **串後端**：axios 封裝 / interceptor、`{ success, message, data }` 拆解
- **樣式**：Bootstrap、CSS Modules、Tailwind 任選
- **發布**：`npm run build`、部署流程
- **中型專案演練**：仿照 `C:\jscode\ordering-frontend` 完整複刻一個三頁點餐系統（改自己的資料來源）
- **里程碑**：完成一個上線可用的 React SPA

---

## 推薦免費資源

| 資源 | 類型 |
|------|------|
| [React 官方文件](https://react.dev/learn) | 文件 |
| [react.dev 互動式教學](https://react.dev/learn) | 線上練習 |
| [MDN Web Docs（JS 基礎）](https://developer.mozilla.org/zh-TW/) | 文件 |
| [React Router 官方文件](https://reactrouter.com) | 文件 |
| [React 官方 Blog（新特性）](https://react.dev/blog) | 新聞 |
| Vite 官方文件 | 建置工具 |
| CodeSandbox / StackBlitz | 線上即時練習 |

---

## 每日時間規劃建議

| 可用時間 | 建議安排 |
|---------|---------|
| 30 分鐘 | 讀一個概念（10 min）+ 改一小段範例（20 min） |
| 1 小時 | 概念教學（20 min）+ 一道元件練習（40 min） |
| 2 小時 | 概念教學（30 min）+ 一道練習（60 min）+ 小專案（30 min） |
| 全天 | 一個完整功能模組（列表 + 表單 + 路由） |

---

## 與 lang-tutor 的分工

- jsx / hooks / 路由 / 框架層面 → 使用本 skill（react-tutor）
- 純 JavaScript / TypeScript 語言語法（如 `===`、Promise、型別系統）→ 使用 lang-tutor