# React 除錯指南

## 錯誤分類與對策

### 1. Hooks 規則違反（Rules of Hooks）

**錯誤訊息（常見）：**
`React has detected a change in the order of Hooks...`
或 `Invalid hook call.`

**常見原因：**
- hook 寫在 if / for / 巢狀函式內
- 事件處理器或一般函式內呼叫 `useState`
- 非 React 元件函式內使用 hook

```jsx
// ❌
function Bad({ ok }) {
  if (ok) {
    const [x, setX] = useState(0) // 條件式呼叫
  }
}

// ✅ hook 永遠在最上層
function Good({ ok }) {
  const [x, setX] = useState(0)
  if (!ok) return null
}
```

### 2. 無限重渲染迴圈（Too many re-renders）

**錯誤訊息：** `Maximum update depth exceeded`

**常見原因：**
- 直接在 render 呼叫 `setState`（如 `setLoading(true)` 寫在元件本體）
- effect 內 setState 且依賴陣列包含自己剛改的值 → 一直重跑

```jsx
// ❌ 每次 render 都 set → 無限迴圈
function Bad() {
  const [t, setT] = useState(0)
  setT(t + 1)
}

// ✅ 放入 useEffect 或事件
function Good() {
  const [t, setT] = useState(0)
  useEffect(() => { setT((v) => v + 1) }, [])
}
```

### 3. stale closure（舊閉包拿舊值）

**症狀：** 畫面 / 邏輯用的值好像「慢了半拍」或一直停在初值。

**常見原因：**
- `useEffect` 依賴陣列沒放進變數
- event listener / setTimeout 綁到了舊 render 的變數

```jsx
// ❌ 依賴陣列空，count 永遠是舊值
useEffect(() => {
  const t = setInterval(() => console.log(count), 1000)
  return () => clearInterval(t)
}, [])

// ✅ 加入依賴，或改用 functional update / ref
useEffect(() => {
  const t = setInterval(() => console.log(count), 1000)
  return () => clearInterval(t)
}, [count])
```

### 4. key 相關警告

**錯誤訊息：** `Each child in a list should have a unique "key" prop`

- 用穩定唯一值當 key（資料庫 id），**不要**用陣列 index（排序 / 刪除會出錯）
- 若資料有雙欄位可拼 `key={`${id}-${status}`}`
- 多 key 分離，避免警告也避免更新錯位

### 5. 相依資料 undefined

**症狀：** `Cannot read properties of undefined (reading 'name')`

**常見原因：**
- 列表仍在 loading 就渲染 `order.items[0].name`
- 後端欄位可缺（如 order 的 `items`）

**防呆方式：**
```jsx
{(order.items || []).map((it) => (
  <div>{it.menuItem ? it.menuItem.name : `#${it.menuItemId}`}</div>
))}
```

### 6. setState 不是同步的

**症狀：** `setState` 後立即 `console.log(state)` 是舊值。

**說明：** React 會批次處理更新，新的 state 在下一次 render 才可用。要看新值用 functional updater 或在其他時機讀。

---

## 除錯流程建議

1. 取得完整錯誤訊息 / Console（區分 `console.error`、`Warning`、網路 4xx/5xx）
2. 縮小範圍：是「編譯錯誤（紅色畫面）」還是「執行錯誤 / 邏輯錯誤」
3. 用「移除 / 註解」二分法：暫時停用某段 JSX 或某個 effect，確認問題源
4. 用 `console.log` 或 React DevTools 檢查 props / state / 觸發時機
5. 根據分類套用上述修正，再驗證一次

**React DevTools：** 建議使用者安裝 React DevTools 擴充功能以查看元件樹與 hooks 值。