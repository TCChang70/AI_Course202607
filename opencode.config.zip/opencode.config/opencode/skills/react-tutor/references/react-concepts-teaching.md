# React 概念教學指南

## 教學結構框架

每個 React 主題的完整教學應依序包含以下段落。

---

## 1. 概念定義（What）

用一段白話說明這個 React 概念是「什麼」，搭配生活比喻。

**格式：**
```
[概念名稱] 是 [比喻說明]。
就像 [生活情境比喻]，讓你可以 [目的]。
```

**範例：**
> `useState` 是 React 用來在元件內「記住會變動的資料」的 Hook。就像店員手上的點餐單，每當內容改變，React 就會重新幫你「重畫」畫面一次。

---

## 2. 使用時機（When）

列舉 3-5 個適合使用的情境。

---

## 3. 結構圖示

用示意圖或骨架標示。範例：

**受控元件骨架：**
```jsx
const [value, setValue] = useState('')
<input
  value={value}
  onChange={(e) => setValue(e.target.value)}
/>
```

**關鍵心智模型：**
- state 變 → re-render → 重畫 UI
- props 由父往子單向傳遞
- 子元件不能直接改 props，要透過父層的 setter

---

## 4. 最小可執行範例（Minimal Example）

規則：
- 單一檔案即可跑的 Function Component
- 附上父元件呼叫方式（必要時）
- 附上「看到的結果」

```jsx
function Counter() {
  const [count, setCount] = useState(0)

  return (
    <button onClick={() => setCount((c) => c + 1)}>
      點我：{count}
    </button>
  )
}
```

---

## 5. 進階用法（Advanced）

展示 2-3 個接近真實專案的應用情境，例如：
- `useState` 進階：functional updater、多欄位表單物件、狀態提升
- `useEffect` 進階：避免過度依賴、cleanup（取消訂閱 / 清除 timer）
- 搭配 axios：`getMenu().then(setItems).catch(...)` + loading/error 三態

---

## 6. 常見錯誤（Common Pitfalls）

格式：
```
❌ 錯誤寫法：
   [程式碼]
   錯誤原因：…

✅ 正確寫法：
   [程式碼]
```

---

## React 主題教學重點

### JSX
- `className` 而非 `class`
- `{}` 內嵌 JavaScript 表達式
- 列表渲染要給 `key`（key 造成警告的後果）
- 行內樣式要用物件：`style={{ color: 'red' }}`
- 條件渲染：`&&`、三元、`??`

### 元件與 props
- props 唯讀（read-only）不能直接改
- `children` 組合、元件拆分與單一職責
- 命名慣例：元件大寫開頭（`MenuManager`），hook 用小寫 `use` 開頭

### state 與渲染
- 畫面是「state 的函式」：`UI = f(state)`
- `setState` 是非同步的，連續呼叫會被批次處理
- 不要直接修改 state 陣列 / 物件，要產生新值
- 狀態提升：把共同 state 移到最近的共同父元件

### 生命週期與 useEffect
- `useEffect` 的時機：渲染之後、依賴變更時、卸載時 cleanup
- 依賴陣列 `[]`（只跑一次）與 `[dep]`（dep 變時重跑）
- 空依賴但存取外部變數 → stale closure

### 路由（react-router-dom v6+ / v7）
- `BrowserRouter` 包住應用、`Routes` + `Route` 定義路徑
- 巢狀路由用 `Outlet` 渲染子路由
- `NavLink` 的 `isActive` 樣式、`useNavigate()` 程式導向
- 動態參數 `:id` 用 `useParams()`
- 404 兜底用 `path="*"`

### 資料請求
- 三態管理：`loading` / `error` / `data`
- axios interceptor 統一拆 `{ success, message, data }` 與錯誤訊息
- 避免在 render 直接發請求（要包在 `useEffect` 或事件處理）
- 防呆：回來的資料欄位可能不存在（`.items || []`）